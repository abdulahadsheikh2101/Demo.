function G(type,c,t){
 const id='g'+Math.random().toString(36).slice(2,7);
 const body='M84 36 L46 54 L16 98 L46 118 L62 102 L62 214 L178 214 L178 102 L194 118 L224 98 L194 54 L156 36 Z';
 let d=`<svg viewBox="0 0 240 240"><defs><linearGradient id="${id}" x1="0" x2="1"><stop offset="0" stop-color="#000" stop-opacity=".22"/><stop offset=".35" stop-color="#fff" stop-opacity=".12"/><stop offset=".7" stop-color="#000" stop-opacity=".04"/><stop offset="1" stop-color="#000" stop-opacity=".24"/></linearGradient></defs>`;
 d+=`<path d="${body}" fill="${c}"/><path d="M92 150 Q102 180 96 214 M150 130 Q142 170 148 214 M76 112 Q86 128 80 150" stroke="#000" stroke-opacity=".1" stroke-width="3" fill="none"/>`;
 if(type==='polo'){
  d+=`<path d="M84 36 L104 32 L121 68 L100 80 Z M156 36 L136 32 L119 68 L140 80 Z" fill="${t}"/><rect x="114" y="64" width="12" height="46" fill="${t}" fill-opacity=".9"/><circle cx="120" cy="78" r="2.4" fill="${c}"/><circle cx="120" cy="96" r="2.4" fill="${c}"/><path d="M16 98 L46 118 L40 128 L9 107 Z M224 98 L194 118 L200 128 L231 107 Z" fill="${t}" fill-opacity=".85"/>`;
 }else if(type==='tee'){
  d+=`<path d="M92 34 Q120 62 148 34 L156 36 Q120 78 84 36 Z" fill="${t}"/><path d="M16 98 L46 118 L40 128 L9 107 Z M224 98 L194 118 L200 128 L231 107 Z" fill="${t}" fill-opacity=".5"/>`;
 }else{
  d+=`<path d="M84 36 L96 28 L120 44 L144 28 L156 36 L146 62 L120 54 L94 62 Z" fill="${t}"/><path d="M120 54 V214" stroke="${t}" stroke-width="4"/><path d="M80 168 H112 V190 H80 Z M128 168 H160 V190 H128 Z" fill="none" stroke="${t}" stroke-opacity=".7" stroke-width="2"/><rect x="62" y="206" width="116" height="8" fill="${t}" fill-opacity=".8"/>`;
 }
 return d+`<path d="${body}" fill="url(#${id})"/></svg>`;
}
const items=[
["Classic Pique Polo","Men · Size M","Polos","polo",2499,6200,"#0F1B2D","#EFE9DA","Grade A","Premium cotton piqué with a ribbed collar and a clean, structured fit. Lightly worn twice."],
["Camel Sport Polo","Women · Size S","Polos","polo",2199,5400,"#B58B5A","#0F1B2D","Grade A","Soft stretch cotton with an athletic cut. Colour and fabric in excellent condition."],
["Stone Knit Polo","Men · Size L","Polos","polo",2299,5800,"#CFC4AE","#0F1B2D","Like new","Fine-gauge knit that drapes well. Worn once, no pilling or marks."],
["Heritage Zip Jacket","Men · Size L","Jackets","jacket",3999,9500,"#24313F","#B3873A","Grade A","Lightweight zip-through jacket with ribbed hem and structured collar."],
["Forest Track Jacket","Unisex · Size M","Jackets","jacket",3499,8200,"#2F4A43","#E9E1CE","Grade B","Relaxed-fit track jacket. Minor wash fade that adds to the character."],
["Essential Crew Tee","Women · Size M","Tees","tee",999,2400,"#ECE6D8","#0F1B2D","Like new","Heavyweight cotton tee, an easy everyday layer. No fading."],
["Slate Blue Tee","Men · Size XL","Tees","tee",1199,2800,"#7C93AB","#0F1B2D","Grade A","Soft-washed cotton with a relaxed neckline. Great for layering."],
["Charcoal Rugby Polo","Men · Size M","Polos","polo",2799,6900,"#2B2F36","#B3873A","Grade A","Heavy rugby-style polo with a contrast collar. Holds its shape wash after wash."],
["Teal Pique Polo","Women · Size M","Polos","polo",2399,5900,"#1F4A4F","#EFE9DA","Like new","Breathable pique with a tailored collar. Worn once for an event."],
["Sand Chore Jacket","Men · Size XL","Jackets","jacket",4299,10500,"#C2AF8B","#0F1B2D","Grade A","Sturdy cotton twill jacket with a classic collar. Softens beautifully."],
["Black Everyday Tee","Unisex · Size L","Tees","tee",899,2200,"#1B1D22","#6B7280","Grade A","Dense, drapey cotton in a deep black that has kept its colour."],
["Ivory Cable Polo","Men · Size S","Polos","polo",2699,6400,"#EFE9DA","#B3873A","Like new","Textured ivory polo with gold-toned trim. Ideal for warm evenings."]
];
const $=id=>document.getElementById(id),grid=$('grid');let cnt=0,io,cat='All',srt='new';
const money=n=>'Rs '+n.toLocaleString();
const cardHTML=i=>`<div class="pic"><span class="cond">${i[8]}</span>${G(i[3],i[6],i[7])}<div class="q">Quick view</div></div><div class="meta"><div><h3>${i[0]}</h3><small>${i[1]}</small></div><div class="pr">${money(i[4])}<s>${money(i[5])}</s></div></div>`;
function bag(n){cnt++;const c=$('count');c.textContent=cnt;c.classList.remove('pop');void c.offsetWidth;c.classList.add('pop');toast(n+' added to bag')}
function drawSlider(){
 const mk=()=>items.map(i=>{const d=document.createElement('article');d.className='card';d.innerHTML=cardHTML(i);d.onclick=()=>openQ(i);return d});
 [...mk(),...mk()].forEach(d=>$('track').appendChild(d));
}
function drawGrid(){
 grid.innerHTML='';
 let l=items.filter(i=>cat==='All'||i[2]===cat);
 if(srt==='lo')l.sort((a,b)=>a[4]-b[4]);if(srt==='hi')l.sort((a,b)=>b[4]-a[4]);
 $('cnt').textContent=l.length+' pieces';
 l.forEach((i,n)=>{const d=document.createElement('article');d.className='card';d.style.transitionDelay=n*50+'ms';d.innerHTML=cardHTML(i);d.onclick=()=>openQ(i);grid.appendChild(d);io.observe(d)});
}
function openQ(i){
 $('mp').innerHTML=G(i[3],i[6],i[7]);
 $('md').innerHTML=`<small style="color:var(--gold2);font-weight:700">${i[2]} · ${i[8]}</small><h2>${i[0]}</h2><div style="font-weight:800;font-size:20px">${money(i[4])} <s style="font-weight:400;color:var(--mute);font-size:15px">${money(i[5])}</s></div><p>${i[9]}</p><div class="sz">${['S','M','L','XL'].map(s=>`<button>${s}</button>`).join('')}</div><button class="btn" id="ab">Add to bag</button><p style="font-size:13px">Authenticated · Professionally cleaned · 7-day returns</p>`;
 document.querySelectorAll('.sz button').forEach(b=>b.onclick=()=>{document.querySelectorAll('.sz button').forEach(x=>x.classList.remove('on'));b.classList.add('on')});
 $('ab').onclick=()=>{bag(i[0]);$('mod').classList.remove('on')};
 $('mod').classList.add('on');
}
$('x').onclick=()=>$('mod').classList.remove('on');
$('mod').onclick=e=>{if(e.target.id==='mod')$('mod').classList.remove('on')};
addEventListener('keydown',e=>{if(e.key==='Escape')$('mod').classList.remove('on')});
io=new IntersectionObserver(e=>e.forEach(x=>{if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target)}}),{threshold:.1});
['All','Polos','Jackets','Tees'].forEach((t,n)=>{const b=document.createElement('button');b.textContent=t;if(!n)b.className='on';b.onclick=()=>{document.querySelectorAll('.tabs button').forEach(x=>x.classList.remove('on'));b.classList.add('on');cat=t;drawGrid()};$('tabs').appendChild(b)});
$('sort').onchange=e=>{srt=e.target.value;drawGrid()};
drawSlider();
$('hg').innerHTML=G('polo','#0F1B2D','#EFE9DA');
/* simple page router: #home, #products, #how */
function route(){
 const h=location.hash.slice(1)||'home',p=h==='products';
 $('v-home').classList.toggle('on',!p);$('v-products').classList.toggle('on',p);
 document.querySelectorAll('.links a').forEach(a=>a.classList.toggle('on',a.dataset.v===(p?'products':h==='how'?'how':'home')));
 if(p){drawGrid();scrollTo(0,0)}else if(h==='how'){const el=$('how');el&&el.scrollIntoView()}else scrollTo(0,0);
}
addEventListener('hashchange',route);route();
let tt;function toast(m){const t=$('toast');t.textContent=m;t.classList.add('show');clearTimeout(tt);tt=setTimeout(()=>t.classList.remove('show'),1800)}
addEventListener('scroll',()=>$('nav').classList.toggle('s',scrollY>10),{passive:true});
const st=$('stage'),hg=$('hg');
st.addEventListener('mousemove',e=>{const r=st.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;hg.style.transform=`rotate(${x*6}deg) translate(${x*18}px,${y*12}px)`});
st.addEventListener('mouseleave',()=>hg.style.transform='');
new IntersectionObserver((e,o)=>e.forEach(x=>{if(!x.isIntersecting)return;o.disconnect();document.querySelectorAll('[data-n]').forEach(el=>{const to=+el.dataset.n,t0=performance.now();(function f(t){const p=Math.min((t-t0)/1600,1);el.textContent=Math.round(to*(1-Math.pow(1-p,3))).toLocaleString()+(to===12000?'+':'');p<1&&requestAnimationFrame(f)})(t0)})}),{threshold:.4}).observe($('stats'));
$('f').onsubmit=e=>{e.preventDefault();toast('Thanks for subscribing');e.target.reset()};
